package com.hungta.dao;

import com.hungta.entity.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {
    User findByUsername(String username);
}
