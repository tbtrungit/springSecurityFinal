package com.hungta.entity;

/**
 * @author HUNGTA on 01/11/18 - 12:42 AM
 * @project restful-mybatis
 */
public class UserAuthority {

    private Long user_id;

    private Long authority_id;

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public Long getAuthority_id() {
        return authority_id;
    }

    public void setAuthority_id(Long authority_id) {
        this.authority_id = authority_id;
    }
}
