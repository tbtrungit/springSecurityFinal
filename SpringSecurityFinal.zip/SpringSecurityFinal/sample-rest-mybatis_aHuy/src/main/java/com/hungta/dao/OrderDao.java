package com.hungta.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.hungta.entity.Order;

/**
 * @author HUNGTA on 01/08/18 - 9:49 PM
 * @project restfulmybatis
 */
@Repository
public interface OrderDao {

    int createOrder(Order order);

    int updateOrder(Order order);

    int deleteOrder(String orderId);

    Order findByOrderName(String orderName);

    Order findByOrderId(String orderId);

   //  @Select("SELECT orderId, productName, quantity, price, type, customerId, customerName, orderDate, total, orderName, status FROM orders")
    List<Order> findAll();
}
