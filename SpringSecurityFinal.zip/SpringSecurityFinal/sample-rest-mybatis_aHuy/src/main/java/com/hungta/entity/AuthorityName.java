package com.hungta.entity;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}