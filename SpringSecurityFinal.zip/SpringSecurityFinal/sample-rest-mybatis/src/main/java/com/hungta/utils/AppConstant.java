package com.hungta.utils;

/**
 * @author HUNGTA on 01/23/18 - 2:08 AM
 * @project restful-mybatis
 */
public class AppConstant {
    public static final String tokenHeader = "Authorization";
}
