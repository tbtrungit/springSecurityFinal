package com.hungta.controller;

/**
 * @author HUNGTA on 01/23/18 - 1:13 AM
 * @project restful-mybatis
 */
public abstract class BaseController {
}
